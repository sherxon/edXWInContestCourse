var express = require('express');
var path = require('path');
var favicon = require('serve-favicon');
var logger = require('morgan');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');
var fs=require('fs');
var index = require('./routes/index');
var users = require('./routes/users');
var validatator=require('express-validator');
var helmet=require('helmet');
var app = express();
app.use(validatator());
app.use(helmet());
app.listen(3000);
// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

// uncomment after placing your favicon in /public
//app.use(favicon(path.join(__dirname, 'public', 'favicon.ico')));
app.use(logger('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

app.use('/', index);
app.use('/users', users);

app.get('/contactus', function(req, res, next){
	res.render('contactus');
})

app.post('/contactus', function(req, res, next){
	req.assert('message', "Message is required").notEmpty();
	req.assert('fullname', "Fullname is required").notEmpty();
	var errs=req.validationErrors();
	res.send(errs);
	if(errs)res.render('contactus', {errs:errs});
	else {
		var data=req.body;
		
		console.log(data);
		data.ip=req.ip;
		fs.writeFile('temp.txt', JSON.stringify(data), function(e){
			console.log(e);
		});
		res.render('thank_you', {fullname:data.fullname});	
	}
	
})


var filterchik=function(req, res, next){
	req.send('filtering');
	return next();
}
var auth=function(req, res){
	req.send('')
}
app.use('/register', function(req, res, next){

	return next();
})
app.use(function(req, res, next){
	res.send('hello me haha');
})

// catch 404 and forward to error handler
app.use(function(req, res, next) {
  var err = new Error('Not Found');
  err.status = 404;
  next(err);
});

// error handler
app.use(function(err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render('error');
});

module.exports = app;
